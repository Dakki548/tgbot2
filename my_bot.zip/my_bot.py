from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext

# Функція для команди /start
def start(update: Update, context: CallbackContext) -> None:
    # Створюємо клавіатуру з двома кнопками
    keyboard = [["Яка найкраща гра в світі?"], ["Який зараз рік?"]]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

    # Відправляємо повідомлення з клавіатурою
    update.message.reply_text("Виберіть питання:", reply_markup=reply_markup)

# Функція для обробки текстових повідомлень (відповідей на кнопки)
def handle_message(update: Update, context: CallbackContext) -> None:
    text = update.message.text

    if text == "Яка найкраща гра в світі?":
        update.message.reply_text("Раст!")
    elif text == "Який зараз рік?":
        update.message.reply_text("2025")
    else:
        update.message.reply_text("Я не розумію цього запитання.")

# Основна функція
def main() -> None:
    # Встав свій токен сюди
    token = '7144800939:AAEtdig71nXXxErHe-wWyEXKo2RomuIgApU'
    updater = Updater(token)

    # Отримуємо диспетчер для реєстрації обробників
    dispatcher = updater.dispatcher

    # Реєструємо обробник для команди /start
    dispatcher.add_handler(CommandHandler("start", start))

    # Реєструємо обробник для текстових повідомлень
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))

    # Запускаємо бота
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
    